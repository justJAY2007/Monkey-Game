
var monkey , monkey_running, monkeyAnimation
var banana ,bananaImage, obstacle, obstacleImage
var FoodGroup, obstacleGroup
var score
var ground

function preload(){
  
  monkeyImage = loadAnimation ("sprite_0.png","sprite_1.png","sprite_2.png","sprite_3.png","sprite_4.png","sprite_5.png","                                sprite_6.png","sprite_7.png","sprite_8.png"); 
  
  bananaImage = loadImage("banana.png");
  obstaceImage = loadImage("obstacle.png");
 
}



function setup() {
  
  createCanvas(600,600);
  
  ground = createSprite(300,590,680,30)
  ground.velocityX = 2
  
  monkey = createSprite(10,580,20,20)
  monkey.addImage(monkeyAnimation);
  
  monkey.setCollider("circle",0,0,40,40);
  
  score = 0;
  fruitGroup = createGroup();
  obstaclesGroup = createGroup();
  
}


function draw() {
  background("lightblue");
  
  fruits();
  obstacles();
  
  ground.velocityX = -2;
  
  if(ground.x < 0){
    background.x = background.width/2;
    
    if(keyDown("space")){
      monkey.y = 5;
    }
    
    if(World.frameCount % 100 == 0){
      obstacle = createSprite(550,550,20,20)
    }
  }

  drawSprites();
}






